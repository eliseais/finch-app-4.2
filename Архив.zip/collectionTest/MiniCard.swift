//
//  MiniCard.swift
//  collectionTest
//
//  Created by Елизавета Андреянова on 19.04.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import UIKit

class MiniCard: UICollectionViewCell {
   
}
